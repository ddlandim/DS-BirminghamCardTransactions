# 2014
## Abril
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/b4a15ade-11b1-4c98-88a0-8cd8408212ac/download/purchasecardtransactionsapril2014.xls

## May
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/a8ebbfdc-6aa1-485c-b8ea-9f63f578ec33/download/purchasecardtransactionsmay2014.xls

## June
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/70bb21b9-4d25-4a73-b641-faa42b02fda0/download/purchasecardtransactionsjune2014.xls

## July
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/211b6316-7473-43b7-8461-70cfe4df076e/download/purchasecardtransactionsjuly2014.xls

## August
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/f82e01b9-9bab-4ef5-b507-749cce10a7a8/download/purchasecardtransactionsaugust2014.xls

## November
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/d1e4ec86-3ce3-4769-851d-63eda74253bf/download/purchasecardsnov2014.xls

## Dez
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/4c0d83d4-3687-4b93-aaae-5302f923404c/download/purchasecardsdec2014.xls

# 2015

## jan
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/e2915c72-08ff-43d5-a587-64d8b872fbb9/download/purchaseccardtransactionsjanuary2015.xls

## fev
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/250c1c19-5741-421c-b769-bfc0e41d7078/download/publishspendpurchasecardsfebruary.xls

## mar
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/bd99f40a-5745-421f-af47-4273d740f706/download/publishspendpurchasecardsmarch.xls

## may
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/30e9eb6e-90cc-4e53-90df-1e504ea7f5ce/download/svlrdclr05homesharechexefinainmngeneralappublishspendmay2015.xls

## jun
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/1ebb6925-a19e-41ff-8167-23a36d804519/download/publishspendjune2015alldirectorates.xls

## jul
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/6fc51bfe-27e1-4184-a4e0-80dd62f7c1c3/download/itemisedtransactionsjuly2015publishspend.xls

## aug
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/dc76ff9d-ba28-4967-aaba-35cb75bd784f/download/itemisedtransactionsaugust2015publishspendalldirectorates.xls

## sep
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/381f8796-d8e8-4660-9c37-a326232ec09e/download/publishspendseptember2015.xls

## oct
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/b27cb764-8dcc-49b9-a0a8-2a0eda4d9334/download/publishspendoctober2015.xls

## nov
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/2ece31ca-4dfd-4fef-86ae-73beccb25ecb/download/publishspendnovember2015.xls

## dez
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/c93f71a1-18c5-4962-86bb-104e4866471c/download/publishedspenddecember2015.xls

#2016

## jan
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/d43bc2cd-37f0-410d-9e35-35ff25ef52d2/download/publishspendjanuary2016.xls

## fev
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/d026bf1c-e97e-4632-94ea-5dc7163fcf93/download/publishspendfebruary2016.xls

## mar
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/4af96278-1569-4b41-854c-b6af4d0405a4/download/publishspendmarch2016.xls

## abr
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/fa1fc8fe-906c-4378-b353-09f2d19531ef/download/publish-spend-april-2016.xls

## may
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/42f9b5d1-d160-4a2d-aff5-02f1e43f9fe4/download/publish-spend-may-2016.xls

## jun
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/4fa3f136-d528-431d-bb49-07a54c5cc2d9/download/publish-spend-june-2016.xls

## jul
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/0da80df6-97d0-4760-9afc-8bd37746b194/download/publish-spend-july-2016.xls

## ago
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/4b210058-3f78-45ec-8771-ff0f857229f1/download/publish-spend-august-2016.xls

## sep
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/572b0eee-6a72-457f-adc2-01e187043826/download/publish-spend-september-2016.xls

## oct
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/d9607892-de96-42fe-8eb0-2e7b9cf9c667/download/publish-spend-october-2016.xls

## nov
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/b045b0cf-5a0a-4b55-9a46-2a9f528226b5/download/publishing-spend-november-2016.xls

## dez
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/509592b8-7ece-49c5-aab0-f078a6414dec/download/publish-spend-december-2016.xls

# 2017

## jan
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/6d41d6d7-afd0-4746-bea1-edb149209ea4/download/cusersfinainmndesktoppublish-copy-january-2017.xls

## fev
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/03c12730-7a76-4ccf-b288-a6853c3db297/download/cusersfinainmndesktoppublish-spend-february-2017-all-directorates.xls

## mar
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/80c17d83-b7b8-46b4-b34b-00ad714230af/download/cusersfinainmndesktoppublish-spend-march-2017.xls

## may
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/318029c5-a087-41c4-a4ca-39cb610019ec/download/cusersfinainmndesktoppublish-spend-may-2017.xls

## jun
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/cd2b2a61-c8ed-40c1-bf7c-97fdad267005/download/cusersfinainmndesktoppublish-spend-june--2017.xls

## jul
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/26afd07e-b929-40a9-a1a8-d4fd77bd18d2/download/cusersfinainmndesktoppublish-spend-july-2017.xls

## ago
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/1f32d25e-14f6-441e-b08a-5c9842363d80/download/cusersfinainmndesktoppublish-spend-august-2017-all-directorates.xls

## sep
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/0a80ff2e-6cb4-4a86-8588-430706bc7ad1/download/cusersfinainmndesktoppublish-spend-sept-2017.xls

## oct
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/f7d4bf39-b514-4cd5-bd27-db19758afd45/download/cusersfinainmndesktoppublish-spend-october-2017-all-directorates.xls

## nov
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/ed815aaf-bcc7-4296-9397-70fb7eccaaa8/download/cusersfinainmndesktoppublish-spend-november-2017-all-directorates.xls

## dez
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/33eff69b-f7e7-48af-ad93-0324d9f4ca1c/download/open_data_planning_weekly_list.csv

## jan
!wget https://cc-p-birmingham.ckan.io/dataset/cf552d08-cee9-43bf-8c0f-3196a9311799/resource/200906b7-366c-441c-9071-ec9ab086e193/download/cusersfinainmndesktoppublish-spend-january-2018.xls
